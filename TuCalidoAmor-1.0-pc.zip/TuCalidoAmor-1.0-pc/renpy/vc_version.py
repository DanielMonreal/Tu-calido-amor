branch = 'fix'
nightly = True
official = True
version = '8.2.2.24050801'
version_name = '64bit Sensation'
